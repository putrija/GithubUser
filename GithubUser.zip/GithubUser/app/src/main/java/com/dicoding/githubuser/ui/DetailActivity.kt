package com.dicoding.githubuser.ui

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import com.bumptech.glide.Glide
import com.dicoding.githubuser.data.response.DetailUserResponse
import com.dicoding.githubuser.databinding.ActivityDetailBinding
import com.google.android.material.tabs.TabLayoutMediator

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding
    private val viewModel by viewModels<DetailViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.title = "Detail User"

        showLoading(true)

        val userId = intent.getStringExtra("login")
        Log.d("DetailActivity", "UserId: $userId")
        if (userId != null) {
            viewModel.getDetailData(userId)
            val sectionsPagerAdapter = SectionsPagerAdapter(this)
            sectionsPagerAdapter.username = userId
            binding.viewPager.adapter = sectionsPagerAdapter
        } else {
            Toast.makeText(this, "Username tidak ditemukan!", Toast.LENGTH_SHORT).show()
        }

        TabLayoutMediator(binding.tabs, binding.viewPager) { tab, position ->
            tab.text = when (position) {
                0 -> "Followers"
                1 -> "Following"
                else -> ""
            }
        }.attach()


        viewModel.userDetails.observe(this) { userDetails ->
            userDetails?.let { updateUI(it) }
        }

        viewModel.isLoading.observe(this) { isLoading ->
            showLoading(isLoading)
        }
    }

    @SuppressLint("SetTextI18n")
    private fun updateUI(userDetails: DetailUserResponse) {
        binding.tvUsername.text = userDetails.login
        binding.tvName.text = userDetails.name
        Glide.with(this)
            .load(userDetails.avatarUrl)
            .into(binding.ivPhoto)
        binding.tvFollowers.text = "${userDetails.followers} Followers"
        binding.tvFollowing.text = "${userDetails.following} Following"
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }
}