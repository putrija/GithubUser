package com.dicoding.githubuser.ui

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.githubuser.data.response.ItemsItem
import com.dicoding.githubuser.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val layoutManager = LinearLayoutManager(this)
        binding.listUsers.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(this, layoutManager.orientation)
        binding.listUsers.addItemDecoration(itemDecoration)
        val adapter = UserAdapter { item ->
            navigateToDetailActivity(item)
        }
        binding.listUsers.adapter = adapter

        with(binding) {
            searchView.setupWithSearchBar(searchBar)
            searchView.editText.setOnEditorActionListener { _, _, _ ->
                val query = searchView.text.trim().toString()
                Log.d("MainActivity", "Query pencarian: $query")
                if (query.isNotEmpty()) {
                    viewModel.currentUserId = query
                    viewModel.findUser()
                }
                searchView.setupWithSearchBar(searchBar)
                searchView.hide()
                true
            }
        }

        viewModel.listUser.observe(this) { users ->
            adapter.submitList(users)
        }
        viewModel.isLoading.observe(this) {
            showLoading(it)
        }
        viewModel.getToastMessage().observe(this) { event ->
            event.getContentIfNotHandled()?.let { message ->
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
            }
        }

    }


    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    private fun navigateToDetailActivity(item: ItemsItem) {
        val intent = Intent(this, DetailActivity::class.java)
        intent.putExtra("login", item.login)
        startActivity(intent)
    }

}